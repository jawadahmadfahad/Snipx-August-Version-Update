from datetime import datetime
from bson import ObjectId

class User:
    def __init__(self, email, password_hash, first_name=None, last_name=None, _id=None):
        self.email = email
        self.password_hash = password_hash
        self.first_name = first_name
        self.last_name = last_name
        self._id = _id

    def to_dict(self):
        return {
            "email": self.email,
            "password_hash": self.password_hash.decode('utf-8') if isinstance(self.password_hash, bytes) else self.password_hash,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "created_at": datetime.utcnow()
        }

    @staticmethod
    def from_dict(data):
        return User(
            email=data['email'],
            password_hash=data['password_hash'].encode('utf-8') if isinstance(data['password_hash'], str) else data['password_hash'],
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            _id=data.get('_id')
        )
