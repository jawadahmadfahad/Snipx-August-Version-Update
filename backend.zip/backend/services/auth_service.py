import jwt
import bcrypt
from datetime import datetime, timedelta
from models.user import User
from bson.objectid import ObjectId
import os

class AuthService:
    def __init__(self, db):
        self.db = db
        self.users = db.users
        self.secret_key = os.getenv('JWT_SECRET_KEY')

    def register_user(self, email, password, first_name=None, last_name=None):
        if self.users.find_one({"email": email}):
            raise ValueError("Email already registered")

        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
        
        user = User(
            email=email,
            password_hash=password_hash,
            first_name=first_name,
            last_name=last_name
        )
        
        result = self.users.insert_one(user.to_dict())
        return str(result.inserted_id)

    def login_user(self, email, password):
        user = self.users.find_one({"email": email})
        if not user:
            raise ValueError("Invalid email or password")

        if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash']):
            raise ValueError("Invalid email or password")

        token = self.generate_token(str(user['_id']))
        return token, User.from_dict(user)

    def generate_token(self, user_id):
        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(days=1)
        }
        return jwt.encode(payload, self.secret_key, algorithm='HS256')

    def verify_token(self, token):
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            return payload['user_id']
        except jwt.ExpiredSignatureError:
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError:
            raise ValueError("Invalid token")

    def get_user_by_id(self, user_id):
        user = self.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            raise ValueError("User not found")
        return User.from_dict(user)

    def update_user(self, user_id, updates):
        updates['updated_at'] = datetime.utcnow()
        result = self.users.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": updates}
        )
        if result.modified_count == 0:
            raise ValueError("User not found or no changes made")
        return self.get_user_by_id(user_id)